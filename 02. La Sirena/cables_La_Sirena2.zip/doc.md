## Patch Variables:

* __allowClearing__ ```Number```
* __background__ ```Number```
* __brushSize__ ```Number```
* __Cascada__ ```Number```
* __foreground__ ```Number```
* __showhands__ ```Number```

